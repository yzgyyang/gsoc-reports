#!/bin/sh
set -xe

# This script is meant for quick & easy install via:
#   $ curl -fsSL URL_HERE | sh
# On FreeBSD:
#   $ fetch --no-verify-peer -qo - URL_HERE | sh

get_platform() {
	platform=$(uname)
	echo ${uname}
}

command_exist() {
	command -v "$@" > /dev/null 2>&1
}

freebsd_init() {
	${sh_c} 'ASSUME_ALWAYS_YES=yes pkg bootstrap'
	${sh_c} 'pkg update'
	${sh_c} 'pkg install --yes git python3 py36-pip'
}

# For demonstration purposes
depman_init() {
        ${sh_c} 'git clone https://gitlab.com/yzgyyang/package_manager'
	${sh_c} 'cd package_manager && git checkout install && python3 setup.py install'
}

# For demonstration purposes
bear_init() {
	${sh_c} 'pkg install --yes libxml2 libxslt' # For lxml, required by coala-bears
	${sh_c} 'pkg install --yes py36-sqlite3' # Required by coala-bears, only on FreeBSD
	${sh_c} 'git clone https://github.com/yzgyyang/coala-bears'
	${sh_c} 'cd coala-bears && git checkout install && python3 -m pip install -r requirements.txt'
}

# For demonstration purposes
go_install() {
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoErrCheckBear import *; GoErrCheckBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GofmtBear import *; GofmtBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoLintBear import *; GoLintBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoReturnsBear import *; GoReturnsBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoTypeBear import *; GoTypeBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoVetBear import *; GoVetBear.setup_dependencies()"'
	${sh_c} 'cd coala-bears && python3 -c "from bears.go.GoImportsBear import *; GoImportsBear.setup_dependencies()"'
}

setup() {
	user=$(id -un 2>/dev/null || true)
	sh_c='sh -c'

        if [ ${user} != 'root' ]; then
                if command_exist sudo ; then
                        sh_c='sudo -E sh -c'
                elif command_exist su ; then
                        sh_c='su -c'
                else
			echo Error: this installer needs the ability to run commands as root.
                        echo Neither "sudo" or "su" is available on this system.
			exit 1
		fi
	fi

        get_platform
	case ${platform} in
		FreeBSD)
			freebsd_init
			depman_init
			bear_init
			go_install
		;;
	esac
}

setup